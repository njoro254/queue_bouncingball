# Cafeteria Website

A website for cafeteria of college. Made specifically for Square One (Cafeteria of Chitkara University, Punjab.) but can be used for any other cafeteria with some changes.

This website was developed in OCTAHACKS Hackathon.

Any suggestions or changes regarding its improvement are welcome. Feel free to contribute.
